from appium import webdriver
import yaml
import logging
import logging.config
import os

# CON_LOG='../config/log.conf'
# logging.config.fileConfig(CON_LOG)
# logginga=logging.getLogger()

log_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),'../config/log.conf')
logging.config.fileConfig(log_file_path)
logger = logging.getLogger()

def appium_desired():
    # file = open('/Users/chabuduoxiansheng/PycharmProjects/appuim/appium_advance/yaml/desired_capsa.yaml', 'r')
    # data = yaml.load(file)

    with open('/Users/chabuduoxiansheng/PycharmProjects/appuim/kyb_testProject/config/kyb_caps.yaml', 'r',encoding='utf-8-sig') as file:
    #with open('../config/kyb_caps.yaml','r',encoding='utf-8') as file:
        data = yaml.load(file)

    desired_caps={}
    desired_caps['platformName']=data['platformName']
    desired_caps['platformVersion']=data['platformVersion']
    desired_caps['deviceName']=data['deviceName']

    base_dir = os.path.dirname(os.path.dirname(__file__))  # 获取当前路径
    app_path = os.path.join(base_dir, 'app', data['appname']) #获取APP路径

    desired_caps['app']=app_path #使用路径方式
    desired_caps['appPackage']=data['appPackage']
    desired_caps['appActivity']=data['appActivity']
    desired_caps['noReset']=data['noReset']

    desired_caps['unicodeKeyboard']=data['unicodeKeyboard']
    desired_caps['resetKeyboard']=data['resetKeyboard']

    logging.info('start app...')
    driver=webdriver.Remote('http://'+str(data['ip'])+':'+str(data['port'])+'/wd/hub',desired_caps)
    driver.implicitly_wait(8)
    return driver

if __name__ == '__main__':
    appium_desired()

    # with open('../config/kyb_caps.yaml','r',encoding='utf-8') as file:
    #     data = yaml.load(file)
    # base_dir = os.path.dirname(os.path.dirname(__file__)) #获取当前路径
    # print(base_dir)
    # app_path = os.path.join(base_dir,'app',data['appname'])
    # print(app_path)